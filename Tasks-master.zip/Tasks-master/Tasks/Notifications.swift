//
//  Notifications.swift
//  Tasks
//
//  Created by Ufuk Türközü on 26.03.20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation

extension NSNotification.Name {
    static let taskSaved = NSNotification.Name("taskSaved")
}
